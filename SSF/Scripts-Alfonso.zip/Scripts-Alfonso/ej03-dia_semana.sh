#!/bin/bash

#####################################
#
# NOMBRE: ej01-resta.sh
# OBJETIVO: 
# AUTOR:  alfonso 
#
# FECHA: 04-02-2022
#
###################################

dia=$1
mes=$2
anio=$3
diaSemana=`date -d "$anio-$mes-$dia" +%A`
error=$?

echo "El día de la semana de la fecha indicada($dia/$mes/$anio) fue : $diaSemana" 
echo "El codigo de error es $error"
