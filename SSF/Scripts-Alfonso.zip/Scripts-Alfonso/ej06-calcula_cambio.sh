#!/bin/bash

#####################################
#
# NOMBRE: ej06-calcula_cambio.sh
# OBJETIVO: 
# AUTOR: alfonso
# FECHA: 04-02-2022
#
###################################


precio=$1
i=$1

b50=0
b20=0
b10=0
b5=0
m2=0
m1=0

while [ "$i" -gt 0 ]
do
	if [ "$i" -ge 50 ]
	then
		$b50 = $(( $b50 + 1 ))
		$i = $(( $i - 50 ))
		break
	fi

	if [ "$i" -lt 50 && "$i" -ge 20 ]
	then
		$b20 = $(( $b20 + 1 ))
		i = $(( i - 20 ))
		break
	fi

        if [ "$i" -lt 20 && "$i" -ge 10 ]
        then
                $b10 = $(( $b10 + 1 ))
                i = $(( i - 10 ))
                break
	fi

        if [ "$i" -lt 10 && "$i" -ge 5 ]
        then
                $b5 = $(( $b5 +1 ))
                i = $(( i - 5 ))
                break
	fi

        if [ "$i" -lt 5 && "$i" -ge 2 ]
        then
                $m2 = $(( $m2 + 1 ))
                i = $(( i - 2 ))
                break
	fi

        if [ "$i" -lt 2 && "$i" -ge 1 ]
        then
                $m1 = $(( $m1 + 1 ))
                i = $(( i - 1 ))
                break
	fi
done
	echo "$precio euros son $b50 billetes de 50 $b20 billetes de 20 $b10 billetes de 10 $b5 billetes de 5"
	echo " $m2 monedas de 2 y $m1 monedas de 1"




