#!/bin/bash

#####################################
#
# NOMBRE: ej04-calcula_segundos.sh
# OBJETIVO: 
# AUTOR: alfonso
# FECHA: 04-02-2022
#

###################################

dias=$1
horas=$2
minutos=$3
segundos=$4


segundosTotales=$((($dias*86400)+($horas*3600)+($minutos*60)+$segundos))

echo " $dias días, $horas horas, $minutos minutos, $segundos segundos son $segundosTotales segundos"

