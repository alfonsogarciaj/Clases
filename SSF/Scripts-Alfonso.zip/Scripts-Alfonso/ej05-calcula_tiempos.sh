#!/bin/bash

#####################################
#
# NOMBRE: ej01-resta.sh
# OBJETIVO: 
# AUTOR: alfonso
# FECHA: 04-02-2022
#
###################################

segundos=$1

diaSeg=$(($segundos/86400))
horaSeg=$((($segundos-($diaSeg * 86400))/3600))
minSeg=$((($segundos-($diaSeg * 86400 + $horaSeg * 3600))/60))
segundoSeg=$((($segundos-($diaSeg * 86400 + $horaSeg * 3600 + $minSeg *60))))

echo "$segundos segundos $diaSeg dias $horaSeg horas $minSeg minutos y $segundoSeg segundos"

