#!/bin/bash

#####################################
#
# NOMBRE: ej01-resta.sh
# OBJETIVO: 
# AUTOR: alfonso
# FECHA: 04-02-2022
#
###################################

nombre=$1
apellido=$2
usuario=$3
ID=$RANDOM

echo "Bienvenido, $nombre"
echo "Tus datos son: $nombre $apellido"
echo "Vamos a crear tu usuario: $usuario"
echo "Tu nueva ID es $ID"
