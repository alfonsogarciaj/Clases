#!/bin/bash

#####################################
#
# NOMBRE: ej07-compara.sh
# OBJETIVO: 
# AUTOR: alfonso
# FECHA: 04-02-2022
#

###################################


a=$1
b=$2
NUM_PARAMS=2

if [ "$#" -ne "$NUM_PARAMS" ]
then
	echo "¡ERROR! Debe introducir $NUM_PARAMS argumentos"
	echo "Sintaxis: $0 a b"
	exit 1
fi


if [ "$a" -eq "$b" ]
then
	echo "$a y $b son iguales"
elif [ "$a" -gt "$b" ]
then
        echo "$a es mayor que $b"
else
	echo "$b es mayor que $a"
fi


