#!/bin/bash

#####################################
#
# NOMBRE: ej08-imc.sh
# OBJETIVO: 
# AUTOR: alfonso
# FECHA: 04-02-2022
#

###################################



altura=$1
peso=$2

imc=$(((10000*$peso)/($altura*$altura)))


if [[ "$imc" -ge 30  && "$imc" -le 34,99 ]]
then
	echo "Obesidad leve"

elif [[ "$imc" -ge 35  && "$imc" -le 39,99 ]]
then
	echo "Obesidad media"

elif [[ "$imc" -ge 40 ]]
then
        echo "Obesidad mórbida"

elif [[ "$imc" -lt 16 ]]
then
        echo "Delgadez severa"

elif [[ "$imc" -ge 16  && "$imc" -le 16,99 ]]
then
        echo "Delgadez moderada"

elif [[ "$imc" -ge 17  && "$imc" -le 18,49 ]]
then
        echo "Delgadez leve"

elif [[ "$imc" -ge 18,5  && "$imc" -le 24,99 ]]
then
        echo "Normal"

elif [[ "$imc" -ge 25  && "$imc" -le 29,99 ]]
then
        echo "Preobesidad"

fi
