#!/bin/bash

#####################################
#
# NOMBRE: ej01-resta.sh
# OBJETIVO: 
# AUTOR: alfonso
# FECHA: 04-02-2022
#
#
###################################

a=$1
b=$2
c=$(($a-$b))
echo "El resultado de $a - $b es $c" 
