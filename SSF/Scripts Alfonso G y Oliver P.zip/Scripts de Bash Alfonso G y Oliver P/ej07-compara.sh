#!/bin/bash

##########################################
#
#
#NOMBRE:ej07-compara.sh
#
#AUTOR:Oliver y Alfonso
#
#FECHA:09/02/2022
#
#
#ENTRADA: Dos numeros
#SALIDA:Si un numero es mayor, menor o igual.
#
#VERSION:1.0
#
##########################################



         read -p "Introduzca el primer numero:" n1
         read -p "Introduzca el segundo numero:" n2


         if [ "$n1" -gt "$n2" ] 

then 

echo "El numero $n1 es mayor que $n2"

elif [ "$n1" -eq "$n2" ] 

then

echo "Los numeros son iguales"

elif [ "$n2" -gt "$n1" ] 

then

echo "El numero $n2 es mayor que $n1"

fi

