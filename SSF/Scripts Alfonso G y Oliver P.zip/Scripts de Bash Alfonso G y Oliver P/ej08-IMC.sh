#!/bin/bash


####################################
#
#NOMBRE:IMC.sh
#
#AUTOR:Oliver y Alfonso
#
#FECHA:01/02/2022
#
#ENTRADA: altura y kg
#SALIDA:Indice de masa corporal y rango
#
#
#VERSION:
#
#####################################


kg=$1
cm=$2

IMC=$((( (10000*"$1")/("$2"*"$2") )))

  echo "Su IMC es $IMC" 




if [ "$IMC" -le 16 ]
then

    echo "Delgadez severa"


elif [ "$IMC" -le 17 ]
then

    echo "Delgadez moderada"

elif [ "$IMC" -le 19 ]
then

    echo "Delgadez leve"


elif [ "$IMC" -le 25 ]
then

    echo "Su peso es normal"


elif [ "$IMC" -le 30 ]
then

    echo "Preobesidad"



elif [ "$IMC" -le 35 ]
then

    echo "Obesidad leve"


elif [ "$IMC" -le 40 ]
then

    echo "Obesidad media"


elif [ "$IMC" -ge 40 ]
then

    echo "Obesidad morbida"

fi








