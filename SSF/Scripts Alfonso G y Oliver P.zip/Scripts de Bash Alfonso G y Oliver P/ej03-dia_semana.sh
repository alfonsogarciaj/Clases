#!/bin/bash

#################################
#
#NOMBRE: dia_semana.sh
#OBJETIVO: indicar una fecha y te devuelve el dia que fue
#AUTOR:Oliver y Alfonso
#
#FECHA: 26/01/2022
#
#ENTRADAS: Dia, mes y año
#SALIDAS: Dia de la semana.
#
#
#VERSIONES:
#
##################################


dia=$1
mes=$2
anyo=$3

dow=`date -d "$anyo-$mes-$dia" +%A`

echo "El dia de la semana de la fecha indicada $dia / $mes / $anyo fue: $dow"





