#!/bin/bash

##########################################
#
#
#NOMBRE: ej12-cuadrados.sh
#
#AUTOR: Oliver y Alfonso
#
#FECHA: 03/02/2022
#
#
#ENTRADA: Dos numeros
#SALIDA: los pares entre esos dos numeros y el cuadrado de estos.
#
#
#VERSION:1.0
#
##########################################


echo  "MENU"
echo "_____"

echo "Valor cuadrados de dos numeros y solo muestras los resultados pares"

read -p "Introduzca el primer numero:" n1
read -p "Introduzca el segundo numero:" n2



              cuadrado1=$(("$n1" * "$n1"))

              cuadrado2=$(("$n2" * "$n2"))



       if [ "$cuadrado1"%2 -eq 0 ]
       then

            echo "El cuadrado de $n1 es $cuadrado1 y es par"

        elif
            echo "El resultado es impar y no se mostrara"

         fi



        if [ "$cuadrado2"%2 -eq 0 ]
        then

            echo "El cuadrado de $n2 es $cuadrado2 y es par"

        elif

            echo "El resultado es impar y no se mostrara"

        fi





