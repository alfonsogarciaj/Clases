#!/bin/bash

##########################################
#
#
#NOMBRE:ej05-calcula_tiempos.sh
#
#AUTOR:Oliver y Alfonso
#
#FECHA:09/02/2022
#
#
#ENTRADA: Cantidad de segundos
#SALIDA: Tiempo en dias,horas,minutos y segundos.
#
#VERSION:1.0
#
##########################################

read -p "Introduzca el numero de segundos:" seg


segundos=$((seg%60))

min=$((seg/60))

horas=$((min/60))

dias=$((horas/24))

minutos=$((min%60))



echo "El tiempo en segudos son: $dias dias,$horas horas,$minutos minutos y $segundos segundos"
