#!/bin/bash

#################################
#
#NOMBRE:ej02.sh
#
#AUTOR:Oliver y Alfonso
#
#FECHA:25/01/2022
#
#ENTRADA: Se pide usuario,nombre,apellido y se da un ID al azar. 
#SALIDA: datos introducidos
#
#
###################################

usuario=$1
nombre=$2
apellido=$3
ID=$RANDOM



echo "Bienvenido $2"

echo "Tus Datos son: $2 $3"

echo "Vamos a crear tu usuario: $1"

echo "Tu nuevo ID es: $RANDOM"


