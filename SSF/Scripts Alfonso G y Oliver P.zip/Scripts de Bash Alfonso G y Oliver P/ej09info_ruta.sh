#!/bin/bash

#################################
#
#NOMBRE: ej9info_ruta
#OBJETIVO: Mostrar informacion de ficheros,directorios,etc
#AUTOR:Oliver y Alfonso
#
#FECHA:31/01/2022
#
#ENTRADAS: ruta
#SALIDAS: informacion sobre la ruta
#
#
#VERSIONES:1.0
#
##################################


#################################
#INFORMACION DE LA RUTA
#
#################################


NUM_PARAMS=1

if [ "$#" -ne "NUM_PARAMS" ]
then

        echo "ERROOOOOOR!!!"
        echo "Sintaxis: $0 ruta"
        exit 1
fi


# Capturo la ruta

ruta=$1


#Compruebo si existe

if ! [ -e "$ruta" ] 
then

       echo"ERROR!! La ruta $ruta no existe"
       exit $ERROR_NO_EXISTE

fi

#Indico el tipo

if [ -f "$ruta" ]
then

       echo "$ruta es un fichero"
elif [ -h "$ruta" ]
then

       echo "$ruta es un enlace"

elif [ -d "$ruta" ]
then

       echo "$ruta es un directorio"

else

       echo "$ruta incorrecta"

fi



#Indico los permisos que tiene




permiso=" "


echo" Permiso de lectura"
if [ -r "$ruta" ] 
then 

       echo "SI"
       permiso="r"
else 

       echo"NO"
       permiso="-"

fi


echo "permiso de escritura"
if [ -w "$ruta" ] 
then 

       echo "SI"
       permiso="w"
else 

       echo"NO"
       permiso="-"

fi


echo "permiso de ejecucion"

if [ -x "$ruta" ] 
then 

       echo "SI"
       permiso="x"
else 

       echo"NO"
       permiso="-"

fi


if [ -s "$ruta" ]
then 

      echo"ESTA VACIO"

else 

       echo " El fichero no esta vacio"

fi


       


