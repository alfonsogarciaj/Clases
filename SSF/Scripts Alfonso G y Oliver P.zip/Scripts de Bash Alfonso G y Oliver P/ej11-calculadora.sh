#!/bin/bash

#########################
#
#NOMBRE:calculadora.sh
#
#AUTOR: Oliver y Alfonso
#
#FECHA: 03/02/2022
#
#
#ENTRADA: resta, suma, division
#SALIDA: calculo matematico
#
#VERSION: 1.0
#
#
########################




     echo "BIENVENIDO A LA CALCULADORA"
     echo "---------------------------"
     echo " "
     echo "1:Suma"
     echo "2:Resta"
     echo "3:Multiplicacion"
     echo "4:Division"
     echo "5:Resto de la division"
     echo "6:Area de un triangulo"
     echo "7:Salir"


read -p "Indique su operacion:" opcion



case $opcion in

1)      

         read -p "Introduzca el primer numero:" n1
         read -p "Introduzca el segundo numero:" n2


          echo "El resultado de Sumar $n1 y $n2 = $(($n1+$n2))"
          ;;

2)

         read -p "Introduzca el primer numero:" n1
         read -p "Introduzca el segundo numero:" n2


          echo "El resultado de restar $n1 y $n2 = $(($n1-$n2))"
          ;;


3)

           read -p "Introduzca el primer numero:" n1
           read -p "Introduzca el segundo numero:" n2


          echo "El resultado de multiplicar $n1 y $n2 = $(($n1*$n2))"
          ;;



4)

           read -p "Introduzca el primer numero:" n1
           read -p "Introduzca el segundo numero:" n2


          echo "El resultado de dividir $n1 y $n2 = $(($n1/$n2))"
          ;;



5)


         read -p "Introduzca el primer numero:" n1
         read -p "Introduzca el segundo numero:" n2


          echo "El resto de la division de $n1 y $n2 es = $(($n1%$n2))"
          ;;




6) 


         read -p "Introduzca la base:" base
         read -p "Introduzca la altura:" altura


          echo "El area del triagunlo con base $base y altura $altura es = $(( ($base*$altura)/2 ))"
          ;;




7)

            
            ;;


*) 

        echo "No es una opcion valida"


esac 
