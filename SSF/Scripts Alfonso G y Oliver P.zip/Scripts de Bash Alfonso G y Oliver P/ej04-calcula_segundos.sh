#!/bin/bash


#################################
#
#NOMBRE: Calcular segundos
#OBJETIVO: Poniendo los datos calculas cualtos segundos son
#AUTOR:Oliver y Alfonso
#
#FECHA: 26/01/2022
#
#ENTRADAS: Dias, Horas, Minutos y Segundos
#SALIDAS: Tiempo en segundos
#
#
#VERSIONES: 1.0
#
##################################


dias=$1
horas=$2
minutos=$3
segundos=$4

cs= $(( ("$dias"*24*60*60)+("$horas"*60*60)+("$minutos"*60)+("$segundos") ))

error=$?


 echo  "$1 Dias , $2 Horas , $3 Minutos , $4 segundos son $cs segundos"



echo "EL codigo de error es $error"



