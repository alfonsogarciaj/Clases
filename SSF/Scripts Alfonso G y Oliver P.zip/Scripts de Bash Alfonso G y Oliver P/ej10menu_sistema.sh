#!/bin/bash

#########################
#
#NOMBRE:ejer10.sh
#
#AUTOR:Oliver y Alfonso
#
#FECHA: 28/01/2022
#
#
#ENTRADA: Menu 
#SALIDA:Diferentes opciones del menu
#
#VERSION: 1.0
#
#
########################




     echo "MENU"
     echo "----"
     echo " "
     echo "1:Indica el espacio libre de la particion raiz(en porcentaje)"
     echo "2:Indica el espacio libre de la particion raiz(en tamaño)"
     echo "3:Indica el usuario actual"
     echo "4:Indica el nombre de la maquina"
     echo "5:Indica el numero de usuarios del sistema"
     echo "6:Total de espacio usado en todos mis directorios personales"


read -p "Introduzca su opcion:" opcion


case $opcion in 

1)

          df -h
          ;;

2)

          df -l
          ;;

3)

          echo "El usuario actual es $(whoami)"
          ;;


4)

          echo "El nombre de la maquina es: $(hostname)"
          ;;
         
5)

          cut -d: -f1 /etc/passwd
          ;;

6) 

         du -hs --total
         ;;


*) 

        echo "No es una opcion valida"
        ;;
esac

  
