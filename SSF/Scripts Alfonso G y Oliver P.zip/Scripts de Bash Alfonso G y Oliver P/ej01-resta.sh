#!/bin/bash

#######################
#
#NOMBRE: Resta
#
#OBJETIVO: Restar dos numeros introducidos
#AUTOR:Oliver y Alfonso
#FECHA: 23/01/2022
#
#ENTRADA: Dos numeros
#SALIDA: La resta de esos dos numeros
#
#
#########################

a=$1
b=$2


echo " El resultado de restar $1-$2 = $(($1-$2))"





