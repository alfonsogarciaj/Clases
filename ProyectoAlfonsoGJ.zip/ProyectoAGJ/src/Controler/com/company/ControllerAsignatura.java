package Controler.com.company;

import Connecion.ConectionBD;
import model.com.company.ModelAsignaturas;
import view.com.company.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.MouseEvent;

//Se inicia Controller-ventana de Asignatura
public class ControllerAsignatura implements ActionListener, MouseListener, WindowListener, KeyListener {
    ModelAsignaturas asignatura = new ModelAsignaturas();
    private ViewAsignatura frAsignatura = new ViewAsignatura();
    private final DefaultTableModel m = null;

    //Iniciar Asignatura
    public ControllerAsignatura() {
        iniciarVentana();
        iniciarEventos();
        prepararBaseDatos();
    }

    //Hacer visible la ventana Asignatura
    public void iniciarVentana() {
        frAsignatura.setVisible(true);
    }

    //Cargar la base de datos en la tabla preparada
    public void prepararBaseDatos() {
        frAsignatura.getTableAsignatura().setModel(asignatura.CargaDatos(m));
    }

    //Iniciar botones y textfields de la ventana
    public void iniciarEventos() {
        frAsignatura.getPanelAsignatura().addMouseListener(this);
        frAsignatura.getTableAsignatura().addMouseListener(this);
        frAsignatura.addWindowListener(this);
        frAsignatura.getTextNombre().addActionListener(this);
        frAsignatura.getTextCreditos().addActionListener(this);
        frAsignatura.getComboTipo().addActionListener(this);
        frAsignatura.getTextCurso().addActionListener(this);
        frAsignatura.getTextCuatri().addActionListener(this);
        frAsignatura.getTextIDProfesor().addActionListener(this);
        frAsignatura.getTextIDGrado().addActionListener(this);
        frAsignatura.getVolverButton().addActionListener(this::actionPerformed);
        frAsignatura.getInsertarButton().addActionListener(this::actionPerformed);
        frAsignatura.getBorrarButton().addActionListener(this::actionPerformed);
        frAsignatura.getModificarButton().addActionListener(this::actionPerformed);
        frAsignatura.getBuscarButton().addActionListener(this::actionPerformed);
        frAsignatura.getCargarTablaButton().addActionListener(this::actionPerformed);
        frAsignatura.getLimpiarCamposButton().addActionListener(this::actionPerformed);
        frAsignatura.getTableAsignatura().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    int filaSeleccionada = frAsignatura.getTableAsignatura().getSelectedRow();
                    if (filaSeleccionada != -1) {
                        String nombre = frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 1).toString();
                        String creditos = frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 2).toString();
                        String tipo = frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 3).toString();
                        String curso = frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 4).toString();
                        String cuatrimestre = frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 5).toString();
                        Object idProfesorObj = frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 6);
                        String idProfesor;
                        if (idProfesorObj != null) {
                            idProfesor = idProfesorObj.toString();
                        } else {
                            idProfesor = "";
                        }
                        String idGrado = frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 7).toString();
                        frAsignatura.getTextNombre().setText(nombre);
                        frAsignatura.getTextCreditos().setText(creditos);
                        frAsignatura.getComboTipo().setSelectedItem(tipo);
                        frAsignatura.getTextCurso().setText(curso);
                        frAsignatura.getTextCuatri().setText(cuatrimestre);
                        frAsignatura.getTextIDProfesor().setText(idProfesor);
                        frAsignatura.getTextIDGrado().setText(idGrado);
                    }
                }
            }
        });
    }

    // Funcionalidad de la ventana Asignatura y pasa los valores al modeloAsignatura
    @Override
    public void actionPerformed(ActionEvent e) {
        String entrada = e.getActionCommand();
        switch (entrada) {
            // Vuelve a la ventana principal
            case "Volver":
                new ControllerPrincipal();
                frAsignatura.dispose();
                break;
            //Envia todos los datos de los textFields al modelo
            case "Insertar":
                if (frAsignatura != null) {
                    String nombre = frAsignatura.getTextNombre().getText();
                    String creditosText = frAsignatura.getTextCreditos().getText();
                    String tipo = frAsignatura.getComboTipo().getSelectedItem().toString();
                    String cursoText = frAsignatura.getTextCurso().getText();
                    String cuatriText = frAsignatura.getTextCuatri().getText();
                    String idProfesorText = frAsignatura.getTextIDProfesor().getText();
                    String idGradoText = frAsignatura.getTextIDGrado().getText();
                    if (nombre.isEmpty() || creditosText.isEmpty() || tipo.isEmpty() ||
                            cursoText.isEmpty() || cuatriText.isEmpty() ||
                            idProfesorText.isEmpty() || idGradoText.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Alguno de los campos es nulo o está vacío", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    float creditos;
                    int curso, cuatri, idProfesor, idGrado;
                    try {
                        creditos = Float.parseFloat(creditosText);
                        curso = Integer.parseInt(cursoText);
                        cuatri = Integer.parseInt(cuatriText);
                        idProfesor = Integer.parseInt(idProfesorText);
                        idGrado = Integer.parseInt(idGradoText);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Los campos numéricos deben contener valores válidos", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    if (!verificarIDProfesor(idProfesor)) {
                        JOptionPane.showMessageDialog(null, "El ID Profesor debe corresponder a alguno existente", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    if (idGrado < 1 || idGrado > 10) {
                        JOptionPane.showMessageDialog(null, "El ID Grado debe estar en el rango del 1 al 10", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    ModelAsignaturas modelAsignaturas = new ModelAsignaturas();
                    modelAsignaturas.insertarAsignatura(nombre, creditos, tipo, curso, cuatri, idProfesor, idGrado);
                    frAsignatura.getTableAsignatura().setModel(asignatura.CargaDatos(m));
                } else {
                    System.out.println("frAsignatura es nula");
                }
                break;
            //Crea una ventana para ingresar el id de la asignatura a borrar para enviarla al modelo
            case "Borrar":
                String idBorrar = JOptionPane.showInputDialog(null, "Ingrese el ID de la asignatura a borrar:", "Borrar asignatura", JOptionPane.PLAIN_MESSAGE);
                if (idBorrar != null && !idBorrar.isEmpty()) {
                    int idAsignaturaBorrar;
                    try {
                        idAsignaturaBorrar = Integer.parseInt(idBorrar);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "El ID de asignatura debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    ModelAsignaturas modelAsignaturas = new ModelAsignaturas();
                    DefaultTableModel modeloTabla = null;
                    try {
                        modeloTabla = modelAsignaturas.buscarAsignatura("ID", idBorrar);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                    // Crear un panel para el diálogo que contendrá la tabla y las opciones que desea el usuario, y así poder modificar también el tamaño de la ventana.
                    if (modeloTabla.getRowCount() > 0) {
                        JTable tabla = new JTable(modeloTabla);
                        JScrollPane scrollPane = new JScrollPane(tabla) {
                            @Override
                            public Dimension getPreferredSize() {
                                return new Dimension(1000, 200);
                            }
                        };
                        Object[] opciones = {"Borrar", "Cancelar"};
                        int opcion = JOptionPane.showOptionDialog(null, scrollPane, "Confirmar borrado de asignatura",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
                        if (opcion == JOptionPane.YES_OPTION) {
                            modelAsignaturas.borrarAsignatura(idAsignaturaBorrar);
                            frAsignatura.getTableAsignatura().setModel(asignatura.CargaDatos(m));
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No se encontraron asignaturas con el ID proporcionado", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            //Al seleccionar un campo de la tabla autorrellena los campos para hacer mas comoda la modificacion y lo envia al modelo
            case "Modificar":
                    int filaSeleccionada = frAsignatura.getTableAsignatura().getSelectedRow();
                    if (filaSeleccionada == -1) {
                        JOptionPane.showMessageDialog(null, "Debes seleccionar una asignatura de la tabla antes de modificar", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    int id = Integer.parseInt(frAsignatura.getTableAsignatura().getValueAt(filaSeleccionada, 0).toString());
                    String nombre = frAsignatura.getTextNombre().getText();
                    String creditosText = frAsignatura.getTextCreditos().getText();
                    String tipo = frAsignatura.getComboTipo().getSelectedItem().toString();
                    String cursoText = frAsignatura.getTextCurso().getText();
                    String cuatriText = frAsignatura.getTextCuatri().getText();
                    String idProfesorText = frAsignatura.getTextIDProfesor().getText();
                    String idGradoText = frAsignatura.getTextIDGrado().getText();

                    if (nombre.isEmpty() || creditosText.isEmpty() || tipo.isEmpty() ||
                            cursoText.isEmpty() || cuatriText.isEmpty() ||
                            idProfesorText.isEmpty() || idGradoText.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Alguno de los campos es nulo o está vacío", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    float creditos;
                    int curso, cuatri, idProfesor, idGrado;
                    try {
                        creditos = Float.parseFloat(creditosText);
                        curso = Integer.parseInt(cursoText);
                        cuatri = Integer.parseInt(cuatriText);
                        idProfesor = Integer.parseInt(idProfesorText);
                        idGrado = Integer.parseInt(idGradoText);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Los campos numéricos deben contener valores válidos", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    if (!verificarIDProfesor(idProfesor)) {
                        JOptionPane.showMessageDialog(null, "El ID Profesor debe corresponder a alguno existente", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    if (idGrado < 1 || idGrado > 10) {
                        JOptionPane.showMessageDialog(null, "El ID Grado debe estar en el rango del 1 al 10", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    ModelAsignaturas modelAsignaturas = new ModelAsignaturas();
                    modelAsignaturas.modificarAsignatura(nombre, creditos, tipo, curso, cuatri, idProfesor, idGrado,id);
                    frAsignatura.getTableAsignatura().setModel(asignatura.CargaDatos(m));
                break;
            //Crea ventana para poder seleccionar con que queremos filtrar la busqueda y se lo pasa al modelo
            case "Buscar":
                    String[] campos = {"ID", "Nombre", "Créditos", "Tipo", "Curso", "Cuatrimestre", "Id Profesor", "Id Grado"};
                    String campoSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione el campo de búsqueda:", "Búsqueda", JOptionPane.PLAIN_MESSAGE, null, campos, campos[0]);
                    if (campoSeleccionado != null) {
                        String valorBusqueda = JOptionPane.showInputDialog(null, "Ingrese el valor a buscar:", "Búsqueda", JOptionPane.PLAIN_MESSAGE);
                        if (valorBusqueda != null && !valorBusqueda.isEmpty()) {
                            ModelAsignaturas modelAsignatura = new ModelAsignaturas();
                            try {
                                frAsignatura.getTableAsignatura().setModel(modelAsignatura.buscarAsignatura(campoSeleccionado, valorBusqueda));
                            } catch (SQLException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                break;
            // Carga la tabla entera de nuevo
            case "Cargar Tabla":
                frAsignatura.getTableAsignatura().setModel(asignatura.CargaDatos(m));
                break;
            //Limpia los campos para poder volver a rellenarlos
            case "Limpiar Campos":
                limpiarCamposAsignatura();
                break;
        }
    }
    //Verifica la lista de los IDprofesor
    private boolean verificarIDProfesor(int idProfesor) {
        List<Integer> listaIDsProfesoresValidos = obtenerListaIDsProfesoresValidos();
        return listaIDsProfesoresValidos.contains(idProfesor);
    }
    //Lista IDprofesor
    private List<Integer> obtenerListaIDsProfesoresValidos() {

        List<Integer> listaIDsProfesoresValidos = new ArrayList<>();
        listaIDsProfesoresValidos.add(3);
        listaIDsProfesoresValidos.add(14);
        listaIDsProfesoresValidos.add(5);
        listaIDsProfesoresValidos.add(15);
        listaIDsProfesoresValidos.add(8);
        listaIDsProfesoresValidos.add(16);
        listaIDsProfesoresValidos.add(10);
        listaIDsProfesoresValidos.add(12);
        listaIDsProfesoresValidos.add(17);
        listaIDsProfesoresValidos.add(18);
        listaIDsProfesoresValidos.add(13);
        listaIDsProfesoresValidos.add(20);
        return listaIDsProfesoresValidos;
    }

    //Vacia los textfields
    public void limpiarCamposAsignatura() {
        frAsignatura.getTextNombre().setText("");
        frAsignatura.getTextCreditos().setText("");
        frAsignatura.getComboTipo().setSelectedIndex(0);  // Establecer el índice seleccionado según tus necesidades
        frAsignatura.getTextCurso().setText("");
        frAsignatura.getTextCuatri().setText("");
        frAsignatura.getTextIDProfesor().setText("");
        frAsignatura.getTextIDGrado().setText("");
    }
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {
        System.out.println("Ha salido del programa");
        frAsignatura.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ConectionBD.closeConn();
    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
}