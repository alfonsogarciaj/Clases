package Controler.com.company;

import Connecion.ConectionBD;
import model.com.company.ModelPersonas;
import view.com.company.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//Se inicia Controller-ventana de Persona
public class ControllerPersona implements ActionListener, MouseListener, WindowListener, KeyListener {

    ModelPersonas persona = new ModelPersonas();
    private final ViewPersona frPersona = new ViewPersona();
    private final DefaultTableModel m = null;

    //Iniciar Persona
    public ControllerPersona() {
        iniciarVentana();
        iniciarEventos();
        prepararBaseDatos();
    }

    //Hacer visible la ventana Persona
    public void iniciarVentana() {
        frPersona.setVisible(true);
    }

    //Cargar la base de datos en la tabla preparada
    public void prepararBaseDatos() {
        frPersona.getTable1().setModel(persona.CargaDatos(m));
    }

    //Iniciar botones y textfields de la ventana
    public void iniciarEventos() {
        frPersona.getPanelPersona().addMouseListener(this);
        frPersona.getTable1().addMouseListener(this);
        frPersona.addWindowListener(this);
        frPersona.getTextDni().addActionListener(this);
        frPersona.getTextNombre().addActionListener(this);
        frPersona.getTextPrimerApellido().addActionListener(this);
        frPersona.getTextSegundoApellido().addActionListener(this);
        frPersona.getTextCiudad().addActionListener(this);
        frPersona.getTextDireccion().addActionListener(this);
        frPersona.getTextTelefono().addActionListener(this);
        frPersona.getTextFechaNacimiento().addActionListener(this);
        frPersona.getComboSexo().addActionListener(this);
        frPersona.getComboTipo().addActionListener(this);
        frPersona.getInsertarButton().addActionListener(this::actionPerformed);
        frPersona.getBorrarButton().addActionListener(this::actionPerformed);
        frPersona.getModificarButton().addActionListener(this::actionPerformed);
        frPersona.getBuscarButton().addActionListener(this::actionPerformed);
        frPersona.getVolverButton().addActionListener(this::actionPerformed);
        frPersona.getCargarTablaButton().addActionListener(this::actionPerformed);
        frPersona.getLimpiarCamposButton().addActionListener(this::actionPerformed);
        frPersona.getTable1().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    int filaSeleccionada = frPersona.getTable1().getSelectedRow();
                    if (filaSeleccionada != -1) {
                        String dni = frPersona.getTable1().getValueAt(filaSeleccionada, 0).toString();
                        String nombre = frPersona.getTable1().getValueAt(filaSeleccionada, 1).toString();
                        String primerApellido = frPersona.getTable1().getValueAt(filaSeleccionada, 2).toString();
                        String segundoApellido = frPersona.getTable1().getValueAt(filaSeleccionada, 3).toString();
                        String ciudad = frPersona.getTable1().getValueAt(filaSeleccionada, 4).toString();
                        String direccion = frPersona.getTable1().getValueAt(filaSeleccionada, 5).toString();
                        Object telefonoObj = frPersona.getTable1().getValueAt(filaSeleccionada, 6);
                        String telefono;
                        if (telefonoObj != null) {
                            telefono = telefonoObj.toString();
                        } else {
                            telefono = "";
                        }
                        String fechaNacimientoText = frPersona.getTable1().getValueAt(filaSeleccionada, 7).toString();
                        String sexo = frPersona.getTable1().getValueAt(filaSeleccionada, 8).toString();
                        String tipo = frPersona.getTable1().getValueAt(filaSeleccionada, 9).toString();

                        // Resto de tu código

                        frPersona.getTextDni().setText(dni);
                        frPersona.getTextNombre().setText(nombre);
                        frPersona.getTextPrimerApellido().setText(primerApellido);
                        frPersona.getTextSegundoApellido().setText(segundoApellido);
                        frPersona.getTextCiudad().setText(ciudad);
                        frPersona.getTextDireccion().setText(direccion);
                        frPersona.getTextTelefono().setText(telefono);
                        frPersona.getTextFechaNacimiento().setText(fechaNacimientoText);
                        frPersona.getComboSexo().setSelectedItem(sexo);
                        frPersona.getComboTipo().setSelectedItem(tipo);
                    }
                }
            }
        });
    }
    // Funcionalidad de la ventana Persona y pasa los valores al modeloPersona
    @Override
    public void actionPerformed(ActionEvent e) {
        String entrada = e.getActionCommand();
        switch (entrada) {
            // Vuelve a la ventana principal
            case "Volver":
                new ControllerPrincipal();
                frPersona.dispose();
                break;
            //Envia todos los datos de los textFields al modelo
            case "Insertar":
                if (frPersona != null) {
                    String dni = frPersona.getTextDni().getText();
                    String nombre = frPersona.getTextNombre().getText();
                    String primerApellido = frPersona.getTextPrimerApellido().getText();
                    String segundoApellido = frPersona.getTextSegundoApellido().getText();
                    String ciudad = frPersona.getTextCiudad().getText();
                    String direccion = frPersona.getTextDireccion().getText();
                    String telefono = frPersona.getTextTelefono().getText();
                    String fechaNacimientoText = frPersona.getTextFechaNacimiento().getText();
                    String sexo = frPersona.getComboSexo().getSelectedItem().toString();
                    String tipo = frPersona.getComboTipo().getSelectedItem().toString();
                    if (!validarCampos(dni, nombre, primerApellido, segundoApellido, ciudad,
                            direccion, telefono, fechaNacimientoText, sexo, tipo)) {
                        return;
                    }
                    Date fechaNacimiento;
                    try {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        fechaNacimiento = dateFormat.parse(fechaNacimientoText);
                    } catch (ParseException ex) {
                        JOptionPane.showMessageDialog(null, "La fecha de nacimiento no tiene un formato válido (dd/MM/yyyy)", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    //Compruebo si el dni/persona existe en la base de datos
                    boolean dniExistente = persona.VerificarDni(dni);
                    if (dniExistente) {
                        return;
                    }
                        ModelPersonas modelPersona = new ModelPersonas();
                        modelPersona.insertarPersona(dni, nombre, primerApellido, segundoApellido, ciudad, direccion, telefono, fechaNacimiento, sexo, tipo);
                        frPersona.getTable1().setModel(persona.CargaDatos(m));
                } else {
                    System.out.println("frPersona es nula");
                }
                break;
                /*
             Crea una ventana para ingresar el id de la asignatura a borrar para enviarla al modelo
             Creo un modelo tabla para cuando se introduzca el dni que se desea borrar, aprovechando el metodo buscarPersona
             nos muestre los datos de esta para confirmar si deseamos borrar.
                 */
            case "Borrar":
                String nifBorrar = JOptionPane.showInputDialog(null, "Ingrese el NIF de la persona a borrar:", "Borrar persona", JOptionPane.PLAIN_MESSAGE);
                if (nifBorrar != null && !nifBorrar.isEmpty()) {
                    ModelPersonas modelPersona = new ModelPersonas();
                    DefaultTableModel modeloTabla = null;
                    try {
                        modeloTabla = modelPersona.buscarPersonas("NIF", nifBorrar);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                    //Creo un panel para el dialogo que contendrá la tabla y las opciones que desea el usuario y asi puedo modificar también el tamaño de la ventana.
                    if (modeloTabla.getRowCount() > 0) {
                        JTable tabla = new JTable(modeloTabla);
                        JScrollPane scrollPane = new JScrollPane(tabla) {
                            @Override
                            public Dimension getPreferredSize() {
                                return new Dimension(700, 200);
                            }
                        };
                        Object[] opciones = {"Borrar", "Cancelar"};
                        int opcion = JOptionPane.showOptionDialog(null, scrollPane, "Confirmar borrado de persona",
                                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
                        if (opcion == JOptionPane.YES_OPTION) {
                            modelPersona.borrarPersona(nifBorrar);
                            frPersona.getTable1().setModel(persona.CargaDatos(m));
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No se encontraron personas con el NIF proporcionado", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                break;
            //Crea ventana para poder seleccionar con que queremos filtrar la busqueda y se lo pasa al modelo
            case "Buscar":
                    String[] campos = {"NIF", "Nombre", "Apellido1", "Apellido2", "Ciudad", "Dirección", "Teléfono", "Fecha Nacimiento", "Sexo", "Tipo"};
                    String campoSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione el campo de búsqueda:", "Búsqueda", JOptionPane.PLAIN_MESSAGE, null, campos, campos[0]);

                    if (campoSeleccionado != null) {
                        String valorBusqueda = JOptionPane.showInputDialog(null, "Ingrese el valor a buscar:", "Búsqueda", JOptionPane.PLAIN_MESSAGE);

                        if (valorBusqueda != null && !valorBusqueda.isEmpty()) {
                            ModelPersonas modelPersona = new ModelPersonas();
                            try {
                                frPersona.getTable1().setModel(modelPersona.buscarPersonas(campoSeleccionado, valorBusqueda));
                            } catch (SQLException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                break;
            // Carga la tabla entera de nuevo
            case "Cargar Tabla":
                frPersona.getTable1().setModel(persona.CargaDatos(m));
                break;
            //Al seleccionar un campo de la tabla autorrellena los campos para hacer mas comoda la modificacion y lo envia al modelo
            case "Modificar":
                    int filaSeleccionada = frPersona.getTable1().getSelectedRow();
                    if (filaSeleccionada == -1) {
                        JOptionPane.showMessageDialog(null, "Debes seleccionar una persona de la tabla antes de modificar", "Alerta", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    String dni = frPersona.getTextDni().getText();
                    String nombre = frPersona.getTextNombre().getText();
                    String primerApellido = frPersona.getTextPrimerApellido().getText();
                    String segundoApellido = frPersona.getTextSegundoApellido().getText();
                    String ciudad = frPersona.getTextCiudad().getText();
                    String direccion = frPersona.getTextDireccion().getText();
                    String telefono = frPersona.getTextTelefono().getText();
                    String fechaNacimientoText = frPersona.getTextFechaNacimiento().getText();
                    String sexo = frPersona.getComboSexo().getSelectedItem().toString();
                    String tipo = frPersona.getComboTipo().getSelectedItem().toString();
                    if (!validarCampos(dni, nombre, primerApellido, segundoApellido, ciudad,
                            direccion, telefono, fechaNacimientoText, sexo, tipo)) {
                        return;
                    }
                    ModelPersonas modelPersona = new ModelPersonas();
                    modelPersona.modificarPersona(dni, nombre, primerApellido, segundoApellido, ciudad, direccion, telefono, fechaNacimientoText, sexo, tipo);
                    frPersona.getTable1().setModel(persona.CargaDatos(m));
                break;
            //Limpia los campos para poder volver a rellenarlos
            case "Limpiar Campos":
                limpiarCamposPersona();
                break;
        }
    }

    public void insertarPersona(String dni, String nombre, String primerApellido, String segundoApellido, String ciudad, String direccion, String telefono, Date fechaNacimiento, String sexo, String tipo) throws SQLException {

    }


    //Valida si los campos estan vacios y si supera el limite de caracteres
    private boolean validarCampos(String dni, String nombre, String primerApellido, String segundoApellido,
                                  String ciudad, String direccion, String telefono, String fechaNacimientoText,
                                  String sexo, String tipo) {
        if (dni.isEmpty() || nombre.isEmpty() || primerApellido.isEmpty() ||
                segundoApellido.isEmpty() || ciudad.isEmpty() ||
                direccion.isEmpty() || telefono.isEmpty() ||
                fechaNacimientoText.isEmpty() || sexo.isEmpty() || tipo.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Alguno de los campos es nulo o está vacío", "Alerta", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (dni.length() > 10 || nombre.length() > 25 || primerApellido.length() > 50 ||
                segundoApellido.length() > 50 || ciudad.length() > 25 || direccion.length() > 50 ||
                telefono.length() > 10) {
            JOptionPane.showMessageDialog(null, "Alguno de los campos excede el límite de caracteres", "Alerta", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    //Vacia los textfields
    public void limpiarCamposPersona() {
        frPersona.getTextDni().setText("");
        frPersona.getTextNombre().setText("");
        frPersona.getTextPrimerApellido().setText("");
        frPersona.getTextSegundoApellido().setText("");
        frPersona.getTextCiudad().setText("");
        frPersona.getTextDireccion().setText("");
        frPersona.getTextTelefono().setText("");
        frPersona.getTextFechaNacimiento().setText("");
        frPersona.getComboSexo().setSelectedIndex(0);
        frPersona.getComboTipo().setSelectedIndex(0);
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {
        System.out.println("Ha salido del programa");
        frPersona.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ConectionBD.closeConn();
    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
}
