package Controler.com.company;

import view.com.company.*;
import javax.swing.*;
import java.awt.event.*;

//Se inicia Controller-ventana Principal
public class ControllerPrincipal implements ActionListener, MouseListener, WindowListener,KeyListener{
    private final ViewPrincipal frPrincipal = new ViewPrincipal();

    //Iniciar Principal
    public ControllerPrincipal(){
        iniciarVentana();
        iniciarEventos();
        frPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    //Iniciar botones
    public void iniciarEventos() {
        frPrincipal.getBtnAsignaturas().addActionListener(this::actionPerformed);
        frPrincipal.getBtnPersonas().addActionListener(this::actionPerformed);
    }

    //Hacer visible ventana Principal
    public void iniciarVentana() {frPrincipal.setVisible(true);}

    //Funcionalidad de la ventana Principal
    @Override
    public void actionPerformed(ActionEvent e) {
        String entrada = e.getActionCommand();
        switch (entrada){
            case "Lista de Personas":
                new ControllerPersona();
                frPrincipal.dispose();
                break;
            case "Lista de Asignaturas":
                new ControllerAsignatura();
                frPrincipal.dispose();
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {
        System.out.println("Ha salido del programa");
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
}
