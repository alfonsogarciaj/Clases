package com.company;

import Controler.com.company.ControllerPrincipal;

public class Main {
    //Inicia controller-ventana Principal
    public static void main(String[] args) {
            new ControllerPrincipal();
    }
}
