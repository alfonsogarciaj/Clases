package model.com.company;

import Connecion.ConectionBD;
import view.com.company.ViewAsignatura;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ModelAsignaturas {

    private Statement stmt;

    //Se conecta a la base de datos
    public ModelAsignaturas() {
        ConectionBD.openConn();
    }

    //Consulta los datos de la base de datos y los muestra
    public DefaultTableModel CargaDatos(DefaultTableModel m) {
        String[] titulos = {"ID", "Nombre", "Créditos", "Tipo", "Curso", "Cuatrimestre", "Id Profesor", "Id Grado"};
        m = new DefaultTableModel(null, titulos);
        try {
            stmt = ConectionBD.getStmt();
            ResultSet rs = stmt.executeQuery("SELECT * FROM asignatura");
            String[] fila = new String[8];
            while (rs.next()) {
                fila[0] = rs.getString("id");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("creditos");
                fila[3] = rs.getString("tipo");
                fila[4] = rs.getString("curso");
                fila[5] = rs.getString("cuatrimestre");
                fila[6] = rs.getString("id_profesor");
                fila[7] = rs.getString("id_grado");
                m.addRow(fila);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return m;
    }

    //Insertar en la base de datos
    public void insertarAsignatura(String nombre, float creditos, String tipo, int curso, int cuatrimestre, int id_profesor, int id_grado) {
        String consulta = "";
        try {
            stmt = ConectionBD.getStmt();
            consulta = "INSERT INTO asignatura VALUES (null,";
            consulta += "'" + nombre + "',";
            consulta += "'" + creditos + "',";
            consulta += "'" + tipo + "',";
            consulta += "'" + curso + "',";
            consulta += "'" + cuatrimestre + "',";
            consulta += "'" + id_profesor + "',";
            consulta += "'" + id_grado + "')";
            stmt.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "La asignatura se agregó correctamente", "Asignatura insertada", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al introducir la asignatura");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
    }

    //Borra la base de datos
    public void borrarAsignatura(int idAsignaturaBorrar) {
        String consultaBorrado = "";
        try {
            stmt = ConectionBD.getStmt();
            consultaBorrado = "DELETE FROM asignatura WHERE id = " + idAsignaturaBorrar;
            int filasBorradas = stmt.executeUpdate(consultaBorrado);
            if (filasBorradas > 0) {
                JOptionPane.showMessageDialog(null, "La asignatura se ha borrado correctamente", "borrada", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ninguna asignatura con el ID especificado", "Error al borrar asignatura", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la asignatura");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
    }

    //Busca en la base de datos
    public DefaultTableModel buscarAsignatura(String campoSeleccionado, String busqueda) throws SQLException {
        String[] titulos = {"ID", "Nombre", "Créditos", "Tipo", "Curso", "Cuatrimestre", "Id Profesor", "Id Grado"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, titulos);
        String consulta = "";
        if (busqueda.isEmpty()) {
            System.out.println("Error: La búsqueda está vacía");
            throw new SQLException("La consulta está vacía");
        }
        switch (campoSeleccionado) {
            case "ID":
                consulta = "SELECT * FROM asignatura WHERE id = '" + busqueda + "'";
                break;
            case "Nombre":
                consulta = "SELECT * FROM asignatura WHERE nombre = '" + busqueda + "'";
                break;
            case "Créditos":
                consulta = "SELECT * FROM asignatura WHERE creditos = '" + busqueda + "'";
                break;
            case "Tipo":
                consulta = "SELECT * FROM asignatura WHERE tipo = '" + busqueda + "'";
                break;
            case "Curso":
                consulta = "SELECT * FROM asignatura WHERE curso = '" + busqueda + "'";
                break;
            case "Cuatrimestre":
                consulta = "SELECT * FROM asignatura WHERE cuatrimestre = '" + busqueda + "'";
                break;
            case "Id Profesor":
                consulta = "SELECT * FROM asignatura WHERE id_profesor = '" + busqueda + "'";
                break;
            case "Id Grado":
                consulta = "SELECT * FROM asignatura WHERE id_grado = '" + busqueda + "'";
                break;
            default:
                break;
        }
        try {
            stmt = ConectionBD.getStmt();
            ResultSet rs = stmt.executeQuery(consulta);
            String[] fila = new String[8];
            while (rs.next()) {
                fila[0] = rs.getString("id");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("creditos");
                fila[3] = rs.getString("tipo");
                fila[4] = rs.getString("curso");
                fila[5] = rs.getString("cuatrimestre");
                fila[6] = rs.getString("id_profesor");
                fila[7] = rs.getString("id_grado");
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            throw e;
        }

        return modeloTabla;
    }

    //Modifica la base de datos
    public void modificarAsignatura(String nombre, float creditos, String tipo, int curso, int cuatrimestre, int id_profesor, int id_grado, int id) {
        String consulta = "";
        try {
            stmt = ConectionBD.getStmt();
            consulta = "UPDATE asignatura SET ";
            consulta += "nombre='" + nombre + "', ";
            consulta += "creditos='" + creditos + "', ";
            consulta += "tipo='" + tipo + "', ";
            consulta += "curso='" + curso + "', ";
            consulta += "cuatrimestre='" + cuatrimestre + "', ";
            consulta += "id_profesor='" + id_profesor + "', ";
            consulta += "id_grado='" + id_grado + "' ";
            consulta += "WHERE id='" + id + "';";
            stmt.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "La asignatura se actualizó correctamente", "Asignatura actualizada", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar la asigantura");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
    }
}