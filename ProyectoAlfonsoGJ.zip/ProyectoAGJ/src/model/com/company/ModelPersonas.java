package model.com.company;

import Connecion.ConectionBD;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ModelPersonas {

    private Statement stmt;

    //Se conecta a la base de datos
    public ModelPersonas() {
        ConectionBD.openConn();
    }

    //Consulta los datos de la base de datos y los muestra
    public DefaultTableModel CargaDatos(DefaultTableModel m) {
        String[] titulos = {"NIF", "Nombre", "Apellido1", "Apellido2", "Ciudad", "Dirección", "Teléfono", "Fecha Nacimiento", "Sexo", "Tipo"};
        m = new DefaultTableModel(null, titulos);
        try {
            stmt = ConectionBD.getStmt();
            ResultSet rs = stmt.executeQuery("select * from persona");
            String[] fila = new String[10];
            while (rs.next()) {
                fila[0] = rs.getString("nif");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("apellido1");
                fila[3] = rs.getString("apellido2");
                fila[4] = rs.getString("ciudad");
                fila[5] = rs.getString("direccion");
                fila[6] = rs.getString("telefono");
                fila[7] = rs.getString("fecha_nacimiento");
                fila[8] = rs.getString("sexo");
                fila[9] = rs.getString("tipo");
                m.addRow(fila);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return m;
    }

    //Insertar en la base de datos
    public void insertarPersona(String dni, String nombre, String primerApellido, String segundoApellido, String ciudad, String direccion, String telefono, Date fechaNacimiento, String sexo, String tipo) {
        String consulta = "";
        try {
            stmt = ConectionBD.getStmt();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String fechaNacimientoStr = dateFormat.format(fechaNacimiento);
            consulta = "INSERT INTO persona VALUES (null,";
            consulta += "'" + dni + "',";
            consulta += "'" + nombre + "',";
            consulta += "'" + primerApellido + "',";
            consulta += "'" + segundoApellido + "',";
            consulta += "'" + ciudad + "',";
            consulta += "'" + direccion + "',";
            consulta += "'" + telefono + "',";
            consulta += "'" + fechaNacimientoStr + "',";
            consulta += "'" + sexo + "',";
            consulta += "'" + tipo + "')";
            stmt.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "La persona se agregó correctamente", "Persona insertada", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al introducir la persona");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
    }

    //Borra la base de datos
    public void borrarPersona(String dniPersonaBorrar) {
        String consultaBorrado = "";
        try {
            stmt = ConectionBD.getStmt();
            consultaBorrado = "DELETE FROM persona WHERE nif = '" + dniPersonaBorrar + "'";
            int filasBorradas = stmt.executeUpdate(consultaBorrado);
            if (filasBorradas > 0) {
                JOptionPane.showMessageDialog(null, "La persona se ha borrado correctamente", "Persona borrada", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ninguna persona con el NIF especificado", "Error al borrar persona", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la persona");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
    }

    //Busca en la base de datos
    public DefaultTableModel buscarPersonas(String campoSeleccionado, String busqueda) throws SQLException {
        String[] titulos = {"NIF", "Nombre", "Apellido1", "Apellido2", "Ciudad", "Dirección", "Teléfono", "Fecha Nacimiento", "Sexo", "Tipo"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, titulos);
        String consulta = "";
        if (busqueda.isEmpty()) {
            System.out.println("Error: La búsqueda está vacía");
            throw new SQLException("La consulta está vacía");
        }
        switch (campoSeleccionado) {
            case "NIF":
                consulta = "SELECT * FROM persona WHERE nif = '" + busqueda + "'";
                break;
            case "Nombre":
                consulta = "SELECT * FROM persona WHERE nombre = '" + busqueda + "'";
                break;
            case "Apellido1":
                consulta = "SELECT * FROM persona WHERE apellido1 = '" + busqueda + "'";
                break;
            case "Apellido2":
                consulta = "SELECT * FROM persona WHERE apellido2 = '" + busqueda + "'";
                break;
            case "Ciudad":
                consulta = "SELECT * FROM persona WHERE ciudad = '" + busqueda + "'";
                break;
            case "Dirección":
                consulta = "SELECT * FROM persona WHERE direccion = '" + busqueda + "'";
                break;
            case "Teléfono":
                consulta = "SELECT * FROM persona WHERE telefono = '" + busqueda + "'";
                break;
            case "Fecha Nacimiento":
                consulta = "SELECT * FROM persona WHERE fecha_nacimiento = '" + busqueda + "'";
                break;
            case "Sexo":
                consulta = "SELECT * FROM persona WHERE sexo = '" + busqueda + "'";
                break;
            case "Tipo":
                consulta = "SELECT * FROM persona WHERE tipo = '" + busqueda + "'";
                break;
            default:
                break;
        }
        try {
            stmt = ConectionBD.getStmt();
            ResultSet rs = stmt.executeQuery(consulta);
            String[] fila = new String[10];
            while (rs.next()) {
                fila[0] = rs.getString("nif");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("apellido1");
                fila[3] = rs.getString("apellido2");
                fila[4] = rs.getString("ciudad");
                fila[5] = rs.getString("direccion");
                fila[6] = rs.getString("telefono");
                fila[7] = rs.getString("fecha_nacimiento");
                fila[8] = rs.getString("sexo");
                fila[9] = rs.getString("tipo");
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            throw e;
        }

        return modeloTabla;
    }

    //Modifica la base de datos
    public void modificarPersona(String dni, String nombre, String primerApellido, String segundoApellido, String ciudad, String direccion, String telefono, String fechaNacimiento, String sexo, String tipo) {
        String consulta = "";
        try {
            stmt = ConectionBD.getStmt();
            consulta = "UPDATE persona SET ";
            consulta += "nif='" + dni + "', ";
            consulta += "nombre='" + nombre + "', ";
            consulta += "apellido1='" + primerApellido + "', ";
            consulta += "apellido2='" + segundoApellido + "', ";
            consulta += "ciudad='" + ciudad + "', ";
            consulta += "direccion='" + direccion + "', ";
            consulta += "telefono='" + telefono + "', ";
            consulta += "fecha_nacimiento='" + fechaNacimiento + "', ";
            consulta += "sexo='" + sexo + "', ";
            consulta += "tipo='" + tipo + "' ";
            consulta += "WHERE nif='" + dni + "';"; // Especifica la columna nif en la cláusula WHERE
            stmt.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "La persona se actualizó correctamente", "Persona actualizada", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar la persona");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
    }

    public boolean VerificarDni(String dni) {
        boolean existe = false;
        String consulta = "";
        try {
            stmt = ConectionBD.getStmt();
            consulta = "SELECT COUNT(*) FROM persona WHERE nif = '" + dni + "';";
            ResultSet resultado = stmt.executeQuery(consulta);
            System.out.println(resultado);
            if (resultado.next()) {
                int resultadoCuenta = resultado.getInt(1);
                if (resultadoCuenta > 0) {
                    existe = true;
                    JOptionPane.showMessageDialog(null, "El DNI ya existe en la base de datos", "DNI Duplicado", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar la persona");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
        return existe;
    }
    public String obtenerPersona(String dni) {
        String consulta = "SELECT * FROM personas WHERE nif = '" + dni + "';";
        String persona = "";
        try {
            stmt = ConectionBD.getStmt();
            ResultSet resultado = stmt.executeQuery(consulta);
            if (resultado.next()) {
                String nombre = resultado.getString("nombre");
                String tipo = resultado.getString("tipo");
                persona = dni + nombre + tipo;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener la persona");
            e.printStackTrace();
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexión con la base de datos");
            e.printStackTrace();
        }
        return persona;
    }
}


