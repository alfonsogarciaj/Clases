package view.com.company;

import javax.swing.*;
import java.awt.*;

public class ViewPrincipal extends JFrame{
    private JButton btnPersonas;
    private JButton btnAsignaturas;
    private JLabel titulo;
    private JPanel panel1;

    public ViewPrincipal() {

        super("Universidad AGJ");
        setContentPane(panel1);
        setSize(1110, 650);
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((pantalla.width - getWidth()) / 2, (pantalla.height - getHeight()) / 2);
        ImageIcon icono = new ImageIcon("C:\\Users\\alfon\\OneDrive\\Escritorio\\ProyectoAGJ\\src\\Imagen\\com\\company\\icono.png");
        setIconImage(icono.getImage());
    }

    public JPanel getPanel1() {
        return panel1;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }

    public JButton getBtnPersonas() {
        return btnPersonas;
    }

    public void setBtnPersonas(JButton btnPersonas) {
        this.btnPersonas = btnPersonas;
    }

    public JButton getBtnAsignaturas() {
        return btnAsignaturas;
    }

    public void setBtnAsignaturas(JButton btnAsignaturas) {
        this.btnAsignaturas = btnAsignaturas;
    }
}
