package view.com.company;

import Controler.com.company.ControllerAsignatura;

import javax.swing.*;
import java.awt.*;

public class ViewAsignatura extends JFrame {
    private JPanel panelAsignatura;
    private JTable tableAsignatura;
    private JTextField textNombre;
    private JTextField textCreditos;
    private JComboBox comboTipo;
    private JTextField textCurso;
    private JTextField textCuatri;
    private JTextField textIDProfesor;
    private JTextField textIDGrado;
    private JButton volverButton;
    private JButton insertarButton;
    private JButton borrarButton;
    private JButton modificarButton;
    private JButton buscarButton;
    private JButton aceptarModificaciónButton;
    private JButton cargarTablaButton;
    private JButton limpiarCamposButton;


    public ViewAsignatura() {
        super("Lista de Asignaturas");
        setContentPane(panelAsignatura);
        setSize(1400, 750);
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((pantalla.width - getWidth()) / 2, (pantalla.height - getHeight()) / 2);
        ImageIcon icono = new ImageIcon("C:\\Users\\alfon\\OneDrive\\Escritorio\\ProyectoAGJ\\src\\Imagen\\com\\company\\icono.png");
        setIconImage(icono.getImage());
    }

    public JButton getCargarTablaButton() {
        return cargarTablaButton;
    }

    public void setCargarTablaButton(JButton cargarTablaButton) {
        this.cargarTablaButton = cargarTablaButton;
    }

    public JButton getAceptarModificaciónButton() {
        return aceptarModificaciónButton;
    }

    public void setAceptarModificaciónButton(JButton aceptarModificaciónButton) {
        this.aceptarModificaciónButton = aceptarModificaciónButton;
    }


    public JPanel getPanelAsignatura() {
        return panelAsignatura;
    }

    public void setPanelAsignatura(JPanel panelAsignatura) {
        this.panelAsignatura = panelAsignatura;
    }

    public JTable getTableAsignatura() {
        return tableAsignatura;
    }

    public void setTableAsignatura(JTable tableAsignatura) {
        this.tableAsignatura = tableAsignatura;
    }

    public JTextField getTextNombre() {
        return textNombre;
    }

    public void setTextNombre(JTextField textNombre) {
        this.textNombre = textNombre;
    }

    public JTextField getTextCreditos() {
        return textCreditos;
    }

    public void setTextCreditos(JTextField textCreditos) {
        this.textCreditos = textCreditos;
    }

    public JComboBox getComboTipo() {
        return comboTipo;
    }

    public void setComboTipo(JComboBox comboTipo) {
        this.comboTipo = comboTipo;
    }

    public JTextField getTextCurso() {
        return textCurso;
    }

    public void setTextCurso(JTextField textCurso) {
        this.textCurso = textCurso;
    }

    public JTextField getTextCuatri() {
        return textCuatri;
    }

    public void setTextCuatri(JTextField textCuatri) {
        this.textCuatri = textCuatri;
    }

    public JTextField getTextIDProfesor() {
        return textIDProfesor;
    }

    public void setTextIDProfesor(JTextField textIDProfesor) {
        this.textIDProfesor = textIDProfesor;
    }

    public JTextField getTextIDGrado() {
        return textIDGrado;
    }

    public void setTextIDGrado(JTextField textIDGrado) {
        this.textIDGrado = textIDGrado;
    }

    public JButton getVolverButton() {
        return volverButton;
    }

    public void setVolverButton(JButton volverButton) {
        this.volverButton = volverButton;
    }

    public JButton getInsertarButton() {
        return insertarButton;
    }

    public void setInsertarButton(JButton insertarButton) {
        this.insertarButton = insertarButton;
    }

    public JButton getBorrarButton() {
        return borrarButton;
    }

    public void setBorrarButton(JButton borrarButton) {
        this.borrarButton = borrarButton;
    }

    public JButton getModificarButton() {
        return modificarButton;
    }

    public void setModificarButton(JButton modificarButton) {
        this.modificarButton = modificarButton;
    }

    public JButton getBuscarButton() {
        return buscarButton;
    }

    public void setBuscarButton(JButton buscarButton) {
        this.buscarButton = buscarButton;
    }

    public JButton getLimpiarCamposButton() {
        return limpiarCamposButton;
    }

    public void setLimpiarCamposButton(JButton limpiarCamposButton) {
        this.limpiarCamposButton = limpiarCamposButton;
    }
}