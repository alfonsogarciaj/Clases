package view.com.company;

import javax.swing.*;
import java.awt.*;

public class ViewPersona extends JFrame{

    private JPanel panelPersona;
    private JTable table1;
    private JTextField textDni;
    private JTextField textNombre;
    private JTextField textPrimerApellido;
    private JTextField textSegundoApellido;
    private JTextField textCiudad;
    private JTextField textDireccion;
    private JTextField textTelefono;
    private JTextField textFechaNacimiento;
    private JComboBox comboSexo;
    private JComboBox comboTipo;
    private JButton insertarButton;
    private JButton borrarButton;
    private JButton modificarButton;
    private JButton buscarButton;
    private JButton volverButton;
    private JButton cargarTablaButton;
    private JButton limpiarCamposButton;

    public ViewPersona() {
        super("Lista Personas");
        setContentPane(panelPersona);
        setSize(1450, 750);
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((pantalla.width - getWidth()) / 2, (pantalla.height - getHeight()) / 2);
        ImageIcon icono = new ImageIcon("C:\\Users\\alfon\\OneDrive\\Escritorio\\ProyectoAGJ\\src\\Imagen\\com\\company\\icono.png");

    }

    public JButton getCargarTablaButton() {
        return cargarTablaButton;
    }

    public void setCargarTablaButton(JButton cargarTablaButton) {
        this.cargarTablaButton = cargarTablaButton;
    }

    public JPanel getPanelPersona() {
        return panelPersona;
    }

    public void setPanelPersona(JPanel panelPersona) {
        this.panelPersona = panelPersona;
    }

    public JTable getTable1() {
        return table1;
    }

    public void setTable1(JTable table1) {
        this.table1 = table1;
    }

    public JTextField getTextDni() {
        return textDni;
    }

    public void setTextDni(JTextField textDni) {
        this.textDni = textDni;
    }

    public JTextField getTextNombre() {
        return textNombre;
    }

    public void setTextNombre(JTextField textNombre) {
        this.textNombre = textNombre;
    }

    public JTextField getTextPrimerApellido() {
        return textPrimerApellido;
    }

    public void setTextPrimerApellido(JTextField textPrimerApellido) {
        this.textPrimerApellido = textPrimerApellido;
    }

    public JTextField getTextSegundoApellido() {
        return textSegundoApellido;
    }

    public void setTextSegundoApellido(JTextField textSegundoApellido) {
        this.textSegundoApellido = textSegundoApellido;
    }

    public JTextField getTextCiudad() {
        return textCiudad;
    }

    public void setTextCiudad(JTextField textCiudad) {
        this.textCiudad = textCiudad;
    }

    public JTextField getTextDireccion() {
        return textDireccion;
    }

    public void setTextDireccion(JTextField textDireccion) {
        this.textDireccion = textDireccion;
    }

    public JTextField getTextTelefono() {
        return textTelefono;
    }

    public void setTextTelefono(JTextField textTelefono) {
        this.textTelefono = textTelefono;
    }

    public JTextField getTextFechaNacimiento() {
        return textFechaNacimiento;
    }

    public void setTextFechaNacimiento(JTextField textFechaNacimiento) {
        this.textFechaNacimiento = textFechaNacimiento;
    }

    public JComboBox getComboSexo() {
        return comboSexo;
    }

    public void setComboSexo(JComboBox comboSexo) {
        this.comboSexo = comboSexo;
    }

    public JComboBox getComboTipo() {
        return comboTipo;
    }

    public void setComboTipo(JComboBox comboTipo) {
        this.comboTipo = comboTipo;
    }

    public JButton getInsertarButton() {
        return insertarButton;
    }

    public void setInsertarButton(JButton insertarButton) {
        this.insertarButton = insertarButton;
    }

    public JButton getBorrarButton() {
        return borrarButton;
    }

    public void setBorrarButton(JButton borrarButton) {
        this.borrarButton = borrarButton;
    }

    public JButton getModificarButton() {
        return modificarButton;
    }

    public void setModificarButton(JButton modificarButton) {
        this.modificarButton = modificarButton;
    }

    public JButton getBuscarButton() {
        return buscarButton;
    }

    public void setBuscarButton(JButton buscarButton) {
        this.buscarButton = buscarButton;
    }

    public JButton getVolverButton() {
        return volverButton;
    }

    public void setVolverButton(JButton volverButton) {
        this.volverButton = volverButton;
    }

    public JButton getLimpiarCamposButton() {
        return limpiarCamposButton;
    }

    public void setLimpiarCamposButton(JButton limpiarCamposButton) {
        this.limpiarCamposButton = limpiarCamposButton;
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
