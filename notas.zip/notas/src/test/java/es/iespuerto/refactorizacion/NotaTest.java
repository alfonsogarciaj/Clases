package es.iespuerto.refactorizacion;

import org.junit.jupiter.api.BeforeEach;

public class NotaTest {

    Nota nota;

    @BeforeEach
    public void before() {

    }
}
