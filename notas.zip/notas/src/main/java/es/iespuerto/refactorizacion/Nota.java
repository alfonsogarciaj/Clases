package es.iespuerto.refactorizacion;

import java.util.Scanner;

public class Nota {

    public static void main(String[] args)
    {
        Scanner a = new Scanner(System.in);
        int nota;
        System.out.print("Introduzca una nota: ");
        nota=a.nextInt();

        if(nota>=0 && nota<50) {
            System.out.println("INSUFICIENTE");
        } else if (nota>=50 && nota<=59) {
            System.out.println("SUFICIENTE");
        } else if(nota>=60 && nota<=69) {
            System.out.println("BIEN");
        } else if(nota>=70 && nota<=89) {
            System.out.println("NOTABLE");
        } else if(nota>=90 && nota<=100 ) {
            System.out.println("SOBRESALIENTE");
        }
    }

}
