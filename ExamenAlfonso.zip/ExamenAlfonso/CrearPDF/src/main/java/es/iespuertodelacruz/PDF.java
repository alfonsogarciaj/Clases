package es.iespuertodelacruz;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author alfonsogj
 */
public class PDF {
    /**
     * Metodo main para CrearPFf, imagen y leertxt
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        addPdf pdf = new addPdf();
        pdf.addPage();
        System.out.println("Menú");
        System.out.println("-------");
        System.out.println("Opción 1: Utilizar la ruta default");
        System.out.println("Opcion 2: Utilizar la ruta que ustede desee");
        int opcion = sc.nextInt();sc.nextLine();
        switch (opcion){
            case 1:
                System.out.println("Nombre que quiera dar al archivo(tiene que ser .pdf");
                String nombreArchivo1 = sc.nextLine();
                pdf.leerTxt("src/main/resources/DatosEstadisticos.txt", "/centro.png",
                    "centro", "/home/daw/Escritorio/CrearPDF/"+nombreArchivo1);
                break;
            case 2:
                System.out.println("Escriba la ruta del archivo txt");
                String rutaArchivo = sc.nextLine();
                System.out.println("Escriba la ruta de la imagen");
                String rutaImagen = sc.nextLine();
                System.out.println("Escriba el nombre de la imagen");
                String nombreImagen = sc.nextLine();
                System.out.println("Nombre que quiera dar al archivo(tiene que ser .pdf");
                String nombreArchivo2 = sc.nextLine();
                pdf.leerTxt(rutaArchivo, rutaImagen, nombreImagen,"/home/daw/Escritorio/Alfonso/Clases/Prueba/"+nombreArchivo2);
                break;
            default:
                System.out.println("Eliga una de las dos opciones");
        }
    }

    /**
     * Clase que genera el PDF
     */
    public static class addPdf {
        PDDocument document;
        PDPage page;
        PDPageContentStream contentStream;
        PDImageXObject image;
        float altura = 17;

        /**
         * Constructor de la clase con 4 parametros
         */
        public addPdf() {
            this.document = new PDDocument();
            this.page = new PDPage(PDRectangle.A6);
            this.contentStream = null;
            this.image = null;
        }


        /**
         * metodo para add una pagina al pdf
         * @return retorna true
         * @throws
         */
        public boolean addPage() throws Exception {
            try {
                document.addPage(page);
                this.contentStream = new PDPageContentStream(document, page);
                return true;
            }catch (Exception e){
                throw new Exception("No se ha podido add la pagina" , e);
            }
        }

        /**
         * metodo que agrega el titulo
         * @param texto
         * @return retorna true
         * @throws
         */
        public boolean agregarTitulo(String texto) throws Exception {
            try {
                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 11);
                contentStream.newLineAtOffset(40, page.getMediaBox().getHeight() - this.altura);
                contentStream.showText(texto);
                contentStream.endText();
                this.altura += 6;
                return true;
            }catch (Exception e){
                throw new Exception("No se ha podido add el titulo", e);
            }
        }


        /**
         * metodo que agrega el texto
         * @param texto
         * @return retorna true
         * @throws
         */
        public boolean agregarTexto(String texto) throws Exception {
            try {
                if (texto.length() > 150) {
                    String textoCortado1 = texto.substring(0, 65);
                    String textoCortado2 = texto.substring(65, texto.length());
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA, 6);
                    contentStream.newLineAtOffset(5, page.getMediaBox().getHeight() - this.altura);
                    contentStream.showText(textoCortado1);
                    contentStream.endText();
                    this.altura += 6;
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA, 6);
                    contentStream.newLineAtOffset(5, page.getMediaBox().getHeight() - this.altura);
                    contentStream.showText(textoCortado2);
                    contentStream.endText();
                    this.altura += 6;
                    return true;
                } else {
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA, 6);
                    contentStream.newLineAtOffset(5, page.getMediaBox().getHeight() - this.altura);
                    contentStream.showText(texto);
                    contentStream.endText();
                    this.altura += 6;
                    return true;
                }
            }catch (Exception e){
                throw new Exception("Error al add el texto", e);
            }
        }

        /**
         * metodo que agrega imagen
         * @param direccionImagen
         * @param nombreImagen
         * @throws
         * @return retorna true
         */
        public boolean agregarImagen(String direccionImagen, String nombreImagen) throws Exception {
            try {
                this.image = PDImageXObject.createFromByteArray(document, PDF.class.getResourceAsStream(direccionImagen).readAllBytes(), nombreImagen);
                contentStream.drawImage(image, page.getMediaBox().getWidth() / 2 - (image.getWidth() / 3) / 2, page.getMediaBox().getHeight() - 4 - image.getHeight() / 3,
                    image.getWidth() / 3, image.getHeight() / 3);
                this.altura += image.getHeight() / 3;

                return true;

            }catch (Exception e){

                throw new Exception("No se ha encontrado la imagen en la ruta especificada", e);
            }
        }

        /**
         * metodo que guarda el pdf
         * @param direccion
         * @return
         * @throws
         */
        public String guardarPdf(String direccion) throws Exception {

            try {
                document.save(direccion);
                return "Archivo guardado en: " + direccion;
            }catch (Exception e){

                throw new Exception("No se ha podido guardar", e);

            }
        }

        /**
         * metodo para cerrar
         * @throws
         * @return
         */
        public boolean closeContentStream() throws Exception {
            try {
                this.contentStream.close();
                return true;
            }catch (Exception e){
                throw new Exception("No se ha podido cerrar", e);
            }
        }

        /**
         * metodo que lee el pdf
         * @param rutaArchivo
         * @param rutaImagen
         * @param nombreImagen
         * @param rutaGuardar
         * @return
         * @throws
         */
        public boolean leerTxt(String rutaArchivo, String rutaImagen, String nombreImagen,
                               String rutaGuardar) throws Exception {
            File archivo = null;
            FileReader fr = null;
            BufferedReader br = null;
            double datos[] = null;
            int cantidadDatos = 0;
            String titulosTabla = "";
            agregarImagen(rutaImagen, nombreImagen);
            try {
                archivo = new File(rutaArchivo);
                fr = new FileReader(archivo);
                br = new BufferedReader(fr);
                titulosTabla = br.readLine();
                String[] campos = titulosTabla.split(";");
                datos = new double[campos.length];
                agregarTexto(titulosTabla);
                String linea;
                while ((linea = br.readLine()) != null) {
                    if(linea.contains("Alemania")){
                    agregarTexto(linea);
                    String[] split = linea.split(";");
                    for (int i = 8; i < split.length; i++) {  //esto se aumenta si tiene una columna a la izquierda
                        datos[i] += Double.parseDouble(split[i]);
                    }
                    }
                    if(linea.contains("Austria") | linea.contains("Bélgica") | linea.contains("Dinamarca")){
                        agregarTexto(linea);
                        String[] split = linea.split(";");
                        for (int i = 8; i < split.length; i++) {  //esto se aumenta si tiene una columna a la izquierda
                            datos[i] += Double.parseDouble(split[i]);
                        }
                    }
                    if(linea.contains("Francia") | linea.contains("Eslovaquia") | linea.contains("Hungría")){
                        agregarTexto(linea);
                        String[] split = linea.split(";");
                        for (int i = 8; i < split.length; i++) {  //esto se aumenta si tiene una columna a la izquierda
                            datos[i] += Double.parseDouble(split[i]);
                        }
                    }
                    if(linea.contains("Irlanda") | linea.contains("Liechtenstein") | linea.contains("Luxemburgo")){
                        agregarTexto(linea);
                        String[] split = linea.split(";");
                        for (int i = 8; i < split.length; i++) {  //esto se aumenta si tiene una columna a la izquierda
                            datos[i] += Double.parseDouble(split[i]);
                        }
                    }
                    if(linea.contains("Países Bajos") | linea.contains("Polonia") | linea.contains("República Checa")){
                        agregarTexto(linea);
                        String[] split = linea.split(";");
                        for (int i = 8; i < split.length; i++) {  //esto se aumenta si tiene una columna a la izquierda
                            datos[i] += Double.parseDouble(split[i]);
                        }
                    }
                    if(linea.contains("Reino Unido") | linea.contains("Suiza")){
                        agregarTexto(linea);
                        String[] split = linea.split(";");
                        for (int i = 8; i < split.length; i++) {  //esto se aumenta si tiene una columna a la izquierda
                            datos[i] += Double.parseDouble(split[i]);
                        }
                    }
                    cantidadDatos += 1;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (null != fr) {
                        fr.close();
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            try {
                String total = "Habitantes Totales: ";
                for (int i = 12; i < datos.length; i++) {
                    datos[i] /= cantidadDatos;
                    System.out.println(datos[i]);
                }
                agregarTexto(total);
                closeContentStream();
                guardarPdf(rutaGuardar);
                return true;
            }catch (Exception e){
                throw new Exception("Error al añadir texto", e);
            }
        }
    }
}
