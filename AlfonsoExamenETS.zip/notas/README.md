<div align="justify">

# Refactorización

  <div align="center">
    <img src="https://comolopuedohacer.com/wp-content/uploads/2016/10/13-C%C3%B3mo-obtener-mejores-notas-en-los-ex%C3%A1menes2.jpg" width="400px" >
  </div>

## Descripción (Notas de Exámenes)

Un profesor de informática está realizando una pequeña aplicación para el cálculo de las notas de sus alumnos.
Para ello crea un pequeño programa, que muestra por pantalla la nota.

## Ejercicio

Realiza la refactorización de la código que se adjunta en el proyecto con el 
fin que se optimice el código que se presenta.
## Referencias

</div>
