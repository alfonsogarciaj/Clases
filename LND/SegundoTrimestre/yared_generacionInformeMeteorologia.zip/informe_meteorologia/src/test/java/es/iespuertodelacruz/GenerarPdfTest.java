package es.iespuertodelacruz;

import org.junit.jupiter.api.Test;

public class GenerarPdfTest {

    GenerarPdf pdf = new GenerarPdf();

    @Test
    void testAgregarPagina(){



    }

}
